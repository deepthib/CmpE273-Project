package edu.sjsu.cmpe.projectdemo.domain;

import java.util.ArrayList;

public class AllDonors {

	public static ArrayList<Donor> allDonors = new ArrayList<Donor>();
}
