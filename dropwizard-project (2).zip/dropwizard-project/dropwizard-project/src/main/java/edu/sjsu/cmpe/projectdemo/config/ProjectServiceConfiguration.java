package edu.sjsu.cmpe.projectdemo.config;

import com.yammer.dropwizard.config.Configuration;

public class ProjectServiceConfiguration extends Configuration
{
	
}